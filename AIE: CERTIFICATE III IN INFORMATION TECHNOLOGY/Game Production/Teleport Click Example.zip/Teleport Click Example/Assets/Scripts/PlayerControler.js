#pragma strict

var moveSpeed : float = 0.01f;

var color : float = 0;

function Start () {

}

function Update () {

	if( color > 0) color -= Time.deltaTime;

	var keyWasPressed = false;

	if( Input.GetKey(KeyCode.UpArrow) )
	{
		transform.Translate(0, 0, moveSpeed * Time.deltaTime);
		keyWasPressed = true;
	}
	if( Input.GetKey(KeyCode.DownArrow) )
	{
		transform.Translate(0, 0, -moveSpeed * Time.deltaTime);
		keyWasPressed = true;
	}
	
	if( Input.GetKey(KeyCode.LeftArrow) )
	{
		transform.Rotate(0, -moveSpeed, 0);
		keyWasPressed = true;
	}
	if( Input.GetKey(KeyCode.RightArrow) )
	{
		transform.Rotate(0, moveSpeed, 0);
		keyWasPressed = true;
	}
	
	if( keyWasPressed )
	{
		color += 5 * Time.deltaTime;
		if( color > 1.0f) color = 1.0f;
	}
	
	var renderCol = Color.Lerp(Color.white, Color.red, color);
	GetComponent.<Renderer>().material.color = renderCol;

}


function OnTriggerEnter (other : Collider)
{
    print("It Worked");
}


function Teleport(position : Vector3)
{
	gameObject.transform.position = position;
} 



