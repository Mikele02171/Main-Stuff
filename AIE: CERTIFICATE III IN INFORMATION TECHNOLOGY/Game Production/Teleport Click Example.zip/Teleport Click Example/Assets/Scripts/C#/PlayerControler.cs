//------------------------------
// Author: Aaron Cox
// Description:
// This script should be applied to the player,
// - move the player around the screen with the arrow keys
// - teleport to a given position.


using UnityEngine;
using System.Collections;

public class PlayerControler : MonoBehaviour
{
	public float moveSpeed = 1.0f;
	
	private enum EPlayerState
	{
		IDLE,
		BEGIN_TELEPORT,
		END_TELEPORT
	};
	
	private EPlayerState playerState;
	private Vector3 playerTeleportPosition;
	
	private Vector3 playerTeleportScale;
	private Quaternion playerTeleportRotation;
	
	private float lerpTime = 0.0f;
	public Vector3 lerpOutScale = new Vector3(0.0f, 4.0f, 0.0f);
	public Quaternion lertOutRotation = new Quaternion(0.0f, 100.0f, 0.0f, 180.0f);
	
	
	
	// Use this for initialization
	void Start ()
	{
		playerTeleportScale = gameObject.transform.localScale;
	}
	
	// Update is called once per frame
	void Update ()
	{
		HandleInput();
		
		
		if( playerState == EPlayerState.BEGIN_TELEPORT )
		{
			lerpTime += Time.deltaTime * moveSpeed;
			transform.localScale = Vector3.Slerp(playerTeleportScale, lerpOutScale, lerpTime);
			transform.rotation = Quaternion.Slerp(playerTeleportRotation, lertOutRotation, lerpTime);
			
			if( lerpTime > 1.0f )
			{
				lerpTime = 1.0f;
				playerState = EPlayerState.END_TELEPORT;
				transform.localScale = lerpOutScale;
				transform.rotation = lertOutRotation;
				transform.position = playerTeleportPosition;
			}
		}
		else if( playerState == EPlayerState.END_TELEPORT )
		{
			lerpTime -= Time.deltaTime * moveSpeed;
			
			transform.localScale = Vector3.Slerp(playerTeleportScale, lerpOutScale, lerpTime);
			transform.rotation = Quaternion.Slerp(playerTeleportRotation, lertOutRotation, lerpTime);
			
			if( lerpTime < 0.0f )
			{
				lerpTime = 0.0f;
				playerState = EPlayerState.IDLE;
				transform.localScale = playerTeleportScale;
				transform.rotation = playerTeleportRotation;
			}
		}
	}
	
	void Teleport(Vector3 position)
	{
		playerTeleportPosition = position - new Vector3(0.0f, -1.0f, 0.0f);
		playerTeleportRotation = transform.rotation * lertOutRotation;
		
		playerState = EPlayerState.BEGIN_TELEPORT;
	}
	
	void HandleInput()
	{
		if( Input.GetKey(KeyCode.UpArrow) )
			transform.Translate(0, 0, moveSpeed * Time.deltaTime);
		
		if( Input.GetKey(KeyCode.DownArrow) )
			transform.Translate(0, 0, -moveSpeed * Time.deltaTime);
		
		if( Input.GetKey(KeyCode.LeftArrow) )
			transform.Rotate(0, -moveSpeed, 0);

		if( Input.GetKey(KeyCode.RightArrow) )
			transform.Rotate(0, moveSpeed, 0);
	}
}
