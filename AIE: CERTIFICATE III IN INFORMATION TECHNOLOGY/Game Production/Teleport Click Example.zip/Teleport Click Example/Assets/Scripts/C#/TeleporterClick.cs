using UnityEngine;
using System.Collections;

public class TeleporterClick : MonoBehaviour
{
	
	private bool active = false;
	
	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
		
		if( active == false )
		{
			GetComponent<Renderer>().material.color = Color.white;
			return;
		}
		
		Ray ray = Camera.main.ScreenPointToRay( Input.mousePosition );
		RaycastHit hit;
		
		GetComponent<Renderer>().material.color = Color.blue;
		if( Physics.Raycast(ray, out hit, 100) )
		{
			if( hit.collider.gameObject == gameObject )
			{
				GetComponent<Renderer>().material.color = Color.red;
				if( Input.GetMouseButton(0) )
				{
					print ("It Worked");
					TeleportPlayer();
				}
			}
		}
	}
	
	void Activate()
	{
		active = true;
	}
	
	void DeActivate()
	{
		active = false;
	}
	
	void TeleportPlayer()
	{
		GameObject[] player = GameObject.FindGameObjectsWithTag("Player");
		
		player[0].SendMessage("Teleport", gameObject.transform.position);
	}
}
