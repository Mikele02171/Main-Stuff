using UnityEngine;
using System.Collections;

public class TeleporterControler : MonoBehaviour {
	
	private GameObject lastActiveTeleporter = null;
	private GameObject activeTeleporter 	= null;
	
	private float activeTimeoutReset 		= 3.5f;
	private float activeTimeout 			= 0;
	
	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
		
		if( activeTeleporter == null )
		{
			GameObject[] teleporters = GameObject.FindGameObjectsWithTag("ClickTeleporter");
			int numTeleporters = teleporters.GetLength(0);
			
			int teleporterID = 0;
			do
			{
				teleporterID = Random.Range(0, numTeleporters);
				
			}while( teleporters[teleporterID] == lastActiveTeleporter );
			
			teleporters[teleporterID].SendMessage("Activate");
			activeTeleporter = teleporters[teleporterID];
		}
		else
		{
			activeTimeout -= Time.deltaTime;
			if( activeTimeout <= 0)
			{
				activeTeleporter.SendMessage("DeActivate");
				
				lastActiveTeleporter 	= activeTeleporter;
				activeTeleporter 		= null;
				activeTimeout 			= activeTimeoutReset;
				
			}
		}
	}
}
