﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Rigidbody))]
public class KinematicControls : MonoBehaviour {

    Rigidbody rigidbody;

    public float moveSpeed = 1.0f;

	// Use this for initialization
	void Start () {
        rigidbody = GetComponent<Rigidbody>();
        if (rigidbody == null) {
            Debug.LogError("A Rigidbody component is required.", this);
        }
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void FixedUpdate() {
        
        if (Input.GetKeyDown(KeyCode.J)) {
            Debug.Log("Applying force to " + gameObject.name);
            // This does nothing because we're kinematic and thus ignore forces.
            rigidbody.AddForce(Vector3.up * rigidbody.mass * 300, ForceMode.Force);
        }

        Vector3 moveInput = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        rigidbody.MovePosition(rigidbody.position + moveInput * moveSpeed * Time.deltaTime);
    }
}
