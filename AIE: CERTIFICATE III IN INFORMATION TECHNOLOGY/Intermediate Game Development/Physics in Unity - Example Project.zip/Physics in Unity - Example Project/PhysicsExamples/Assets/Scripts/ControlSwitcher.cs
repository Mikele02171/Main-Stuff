﻿using UnityEngine;
using System.Collections;

public class ControlSwitcher : MonoBehaviour {

    public MonoBehaviour[] controllerScripts;

    private int currentControllerIndex = 0;

    void Start() {
        if (controllerScripts != null && controllerScripts.Length > 0) {
            SetCurrentController(0);
        }
        else {
            Debug.LogError("No controller scripts have been set.", this);
        }
    }

	void Update () {
        if (Input.GetKeyDown(KeyCode.Space)) {
            int desiredIndex = currentControllerIndex + 1;
            if (desiredIndex >= controllerScripts.Length) {
                desiredIndex = 0;
            }
            SetCurrentController(desiredIndex);
        }
	}

    void SetCurrentController(int index) {
        if (index < 0 || index >= controllerScripts.Length) {
            Debug.LogError("Can not set controller index to " + index, this);
            return;
        }

        for (int i = 0; i < controllerScripts.Length; i++) {
            if (controllerScripts[i] != null) {
                controllerScripts[i].enabled = (i == index);
                currentControllerIndex = index;
            }
            else {
                Debug.LogError("Null controller in controllerScripts.", this);
            }
        }
    }

    public string GetCurrentControllerName() {
        return controllerScripts[currentControllerIndex].gameObject.name;
    }
}
