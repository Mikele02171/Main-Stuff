﻿using UnityEngine;
using System.Collections;

public class RigidbodyControls : MonoBehaviour {

    Rigidbody rigidbody;

    public float moveSpeed = 1.0f;

    

    // Use this for initialization
    void Start() {
        rigidbody = GetComponent<Rigidbody>();
        if (rigidbody == null) {
            Debug.LogError("A Rigidbody component is required.", this);
        }
    }

    bool jumpInput = false;

    void Update() {
        // If the button is pressed, set jumpInput to true.
        if (Input.GetKeyDown(KeyCode.J)) {
            jumpInput = true;
        }
    }

    void FixedUpdate() {
        // If jumpInput is true, apply the jump force and then set it back to 
        // false.
        if (jumpInput) {
            Debug.Log("Applying force to " + gameObject.name);
            rigidbody.AddForce(Vector3.up * rigidbody.mass * 300, ForceMode.Force);
            jumpInput = false;
        }

    }

     //   Vector3 moveInput = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
      //  rigidbody.MovePosition(rigidbody.position + moveInput * moveSpeed * Time.deltaTime);
    //}
}
