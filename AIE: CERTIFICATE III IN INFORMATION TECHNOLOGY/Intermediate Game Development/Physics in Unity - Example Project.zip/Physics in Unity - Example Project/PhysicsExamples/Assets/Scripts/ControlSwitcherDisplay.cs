﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[RequireComponent(typeof(Text))]
public class ControlSwitcherDisplay : MonoBehaviour {

    Text text;

    public ControlSwitcher controlSwitcher;

    void Start() {
        text = GetComponent<Text>();
        if (text == null) {
            Debug.LogError(GetType().ToString() + ": No Text component found.", this);
        }

        if (controlSwitcher == null) {
            Debug.LogError("ControlSwitcher has not been set.", this);
        }
    }

    void Update() {
        text.text = "Controlling: " + controlSwitcher.GetCurrentControllerName();
    }
	
}
