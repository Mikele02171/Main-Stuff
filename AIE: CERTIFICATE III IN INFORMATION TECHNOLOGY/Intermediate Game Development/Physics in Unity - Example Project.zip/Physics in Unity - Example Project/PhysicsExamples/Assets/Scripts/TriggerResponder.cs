﻿using UnityEngine;
using System.Collections;

public class TriggerResponder : MonoBehaviour {
    
    void OnTriggerEnter(Collider other) {
        Debug.Log(gameObject.name + " was triggered by a collision with " + other.gameObject.name + ".");
    }
}
