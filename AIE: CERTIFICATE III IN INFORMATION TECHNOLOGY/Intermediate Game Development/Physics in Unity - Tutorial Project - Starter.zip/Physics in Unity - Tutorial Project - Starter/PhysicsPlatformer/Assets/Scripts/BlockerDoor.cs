﻿// ---------------------------------------------+
/// @file BlockerDoor.cs
/// @brief Opens and closes a door.
/// @author AIE
/// @date Jan 2016
/// @version 1.0
// -------------------------------------------+

using UnityEngine;
using System.Collections;

public class BlockerDoor : MonoBehaviour {

    // Where is the door when it is closed?
    Vector3 m_ClosedPosition;

    // Where is the door when it is open?
    Vector3 m_OpenPosition;

    // Is the door currently open or opening?
    private bool m_Open = false;

	void Start () {
        // Save our starting location as the closed position
        m_ClosedPosition = transform.position;

        // When we're open we want to be 2m above our closed position
        m_OpenPosition = transform.position + new Vector3(0, 2.0f, 0);
	}
	
	void Update () {
        // You'll need to fill this in to move towards m_OpenPosition or 
        // m_ClosedPosition depending on the value of m_Open.
	}

    /// <summary>
    /// Lets other scripts open this door.
    /// </summary>
    public void Open() {
        m_Open = true;
    }
}
